# 02 - Animations: how each one works (with the numbers)

All numbers below were read from the code in `reference/`. Locations are given as `file:line` of the original files. Full copies are in `animations/`; the two engines buried inside `system.js` are also excerpted in `animations/excerpts/`.

## 0. Principles the reference follows everywhere

1. **Only `transform` and `opacity` animate.** Never `left/top/width/height`. (Icons move with `translate`, windows with `transform: translate() scale()`.)
2. **State is expressed with classes**, not inline styles: `.open`, `.closing`, `.dragging`, `.settle`, `.launch`, `.pressed`, `.drag`. Each class owns its own transition, so entering and leaving can have different timing.
3. **Start state must be painted before the end state is applied.** `openApp` sets the start transform, then waits **two `requestAnimationFrame`s**, then adds `.open` and clears the inline transform (`system.js:796`). Without this the browser merges both states and nothing animates.
4. **While a finger/mouse is down there is no transition** (`.dragging { transition:none }`, `.pages.drag { transition:none }`); on release a spring transition (`.settle`) takes over.
5. **Layout is never read inside `pointermove`.** Scale/rect are read once per gesture or cached for 250 ms (`UI.zoom()`, `home.js scr()`), so dragging stays at 60 fps.
6. **Every JS animation has a timeout fallback** so it can never stay half way (for example `faAnim` finishes after `ms + 260`).
7. **Reduce Motion** (`System.state.reduceMotion`) replaces movement with a short fade.
8. CEF/FiveM rules noted in `liquid27.css`: no new `filter`/`backdrop-filter`, no `color-mix()`, no `clip-path`, no `calc()` inside `rgba()`. These are safe in a normal browser, but keep them if the prototype must also run in-game.

## 1. Timing tokens and curves

`css/tokens.css:120-125`, `css/motion.css:6`

```
--ease:   cubic-bezier(.32,.72,0,1)      /* iOS navigation ease */
--ios:    cubic-bezier(.32,.72,0,1)
--ios-out:cubic-bezier(.2,.9,.25,1)
--spring: cubic-bezier(.34,1.18,.64,1)   /* restrained spring */
--spring2:cubic-bezier(.34,1.35,.4,1)    /* spring with slight overshoot */
--motion-fast:120ms --motion-normal:220ms --motion-medium:350ms --motion-app:450ms --motion-sheet:480ms
```

## 2. Opening and closing an app (icon <-> window)

CSS: `css/motion.css:25-37`. JS: `system.js:758-858` (excerpt `B_app_launch_close_animation_from_system.js.txt`).

* **Geometry:** `rectOf(tileElement)` measures the tapped icon in screen pixels. `toTransform(r)` turns it into `translate(dx,dy) scale(r.w / SW)` relative to the window centre (`SW` = screen width, 440 or 670/1340 on the fold; the vertical centre constant is 478 = 956/2). The window starts exactly on top of the icon, then its transform is cleared so it grows to full screen.
* **Open:** `.app-window` transition `transform 450ms var(--ios)`, `opacity .14-.18s`. The app *surface* grows from the first frame, but the *content* (`.nav-stack`) only fades in at the end: `opacity .16s ease-out .28s` (the last ~35% of the motion).
* **Close:** `.app-window.closing` -> `transform .42s var(--ios)`, `opacity .16s ease-in .24s` (it shrinks onto the icon and only fades at the very end). Content fades out first (`.12s`).
* **The icon itself:** `.tile.launch { transform:scale(1.45); opacity:0; transition: transform .42s var(--ios-out), opacity .28s .06s }` so the tapped icon "opens" into the app.
* **The home screen behind:** `.screen.app-open #home { transform:scale(1.14); opacity:0; transition: opacity .24s, transform .45s var(--ios) }`; on close it springs back (`.5s var(--spring2)`).
* **Dragging a window** (home indicator): `.app-window.dragging { transition:none; box-shadow:...}`; on release `.settle { transition: transform .55s var(--spring2) }`.

## 3. Gestures that follow the finger (`js/shell/gestures.js`, 235 lines)

* **Home indicator (`.hb-zone`):** drag up and the app becomes a card that follows the finger and shrinks (to about 38%) while the home screen appears behind it. Release fast or high -> `System.closeApp()` (shrinks into its icon). Stop half way and release -> App Switcher. Swipe sideways -> previous app. Release early -> springs back.
* **Left edge (`.edge-zone`):** back swipe; the current view follows the finger and the previous view moves with parallax (`.view { transition: transform .52s var(--ios), filter .52s ... }`).
* **Top zone (`.top-zone`):** right half pulls down the Control Center, left half the Notification Center, both following the finger.
* **Rubber band:** `rubber(d,c=.55,dim=200) = (1 - 1/((d*c/dim)+1)) * dim` gives the resistance past the limit.
* **Mouse support:** `js/shell/dragscroll.js` makes scroll areas draggable with a mouse like a touch screen (needed on desktop).

## 4. App Switcher (`js/shell/switcher.js`, `css` in shell.css)

Recent apps are cards at 62% of the screen, current app centred, older ones to the left (horizontal scroll-snap), icon + name above each card, swipe a card up to close it, tap a card to reopen (the window grows from that card), "close all" button. Entering from the indicator gesture places the card exactly where the app was being dragged.

## 5. Home screen motion (`css/motion.css:8-22`, `js/shell/home.js`)

* Icon position uses `translate` with `transition: translate .45s var(--spring)`.
* Press: `.hi:active .tile { transform:scale(.93); filter:brightness(.72) }` (fast in, spring out).
* Icon drag: `.hi.dragging` removes the translate transition and gives the tile a big shadow (shadow lives on the tile, not `filter: drop-shadow` on the whole icon, because that re-rasterises every frame).
* Pages: `.pages { transition: transform .5s var(--spring2) }`, `.pages.drag { transition:none }` while the finger is down. Wallpaper parallax with `.wallpaper.par`.
* Edit mode (jiggle), folders, widgets resize, App Library and Spotlight are in `home.js` (1277 lines).

## 6. Lock screen (`js/shell/lock.js`, `css/lock.css`, `css/oneui-lock.css` for Android)

Rolling-digit clock, date, widgets, notification stacks, shortcuts (torch/camera), swipe up to the PIN pad, wake animation (`@keyframes lockWake`), PIN dots (`dotPop`), wrong PIN `shake`, unlock animation. `Lock.requestUnlock(cb)` shows the PIN pad and runs `cb` after success: this is how opening an app from outside (deep link, notification tap) unlocks first.

## 7. Notifications and Dynamic Island

* `js/shell/notify.js`: banners (tap opens the app, pull up dismisses, pull down or long-press expands), Notification Center, lock-screen stacks, swipe actions (Options/Clear), per-app settings, history, sounds.
* `js/shell/island.js`: pill with activities by priority (call 3, timer 2, nav 2, activity 2, music 1, download 1); incoming call expands with accept/decline; `Island.activity(id, {...})` for Live Activities; camera/mic indicators.

## 8. THE FOLDABLE: book-style open/close (`system.js:213-475`)

Excerpt: `animations/excerpts/A_foldable_book_animation_from_system.js.txt`. Styles for the frame/hinge rig (`.frig`, `.frig-p`, `.frig-l`, `.frig-r`, `.fold-anim`) are in `css/system.css`.

**Model.** A fold has two states, closed (outer screen 670x956) and open (inner screen 1340x956: same height, double width). `FOLD = { cw:670, ow:1340, dcw:690, dow:1360, ax:680 }` (device = screen + 10 px frame each side; the hinge is always `ax` = 680 px from the right edge of the device).

**Progress variable `p` (0 = closed, 1 = open).** The front half (the closed device) rotates around the hinge like a book cover:

```
th   = -180 * p                       // degrees
leaf.transform = perspective(3800px) rotateY(th) translateX(340px) rotateY(180deg) translateX(-340px)
device.transform (closed geometry) = perspective(3800px) rotateY(th)
```

Pieces:
* **The device in closed geometry is the front of the leaf**, so the outer screen stays alive while it rotates. It disappears from behind after 90 degrees (backface hidden).
* **`.frig` (inserted into `.stage` behind the device)** draws the right half of the inner screen (under the leaf) and the inner face of the leaf (left half), both with the wallpaper.
* **Shading:** `leafK.opacity = (p>.5 ? .5*sin(pi*p) : 0)`, `underK.opacity = .55*(1 - min(1, p*1.6))` so the inner screen "lights up" while opening.
* **Closing from open:** the open device fades on top of the `.frig` (identical look) and switches to the closed geometry when `p < .5` (leaf edge-on, so the swap is invisible).
* **Nothing changes layout mid-animation**; only `transform` and `opacity`. Final state is applied once at the end (`faEnd` -> `applyFold` -> events `fold:state`, `form:changed`, apps and Home re-layout).

**Timings.** `setFoldOpen(true)` = 600 ms `easeInOut` (cubic), close = 500 ms. After a drag: `dur = clamp(180 + 440*distance, 200, 560)` ms with `easeOut`. A tap on the spine without dragging "nudges" (`p` to .07 in 170 ms, back in 280 ms).

**Gesture (the grip).** A 36 px band around the left edge of the device (26 px outside + the 10 px frame, never inside the screen because the screen edge belongs to the Back gesture). Drag left to open, right to close; the sheet follows the pointer, **680 px = the whole way**. Release after 40% of the way or with a fast flick -> completes; otherwise springs back. A drag that is more vertical than horizontal is ignored.

**Public API.** `System.setFoldOpen(open, {instant, ms})` returns a Promise (`true` when finished); `System.foldOpen`; `System.foldAnimating`; `System.form`; `System.SW`. The control-center/quick-panel "Fold" tile just calls `setFoldOpen`.

**Wiring a slider (like "Fold Angle" in a prototype).** The reference has no angle slider; it has `p`. A slider with 0 to 180 degrees maps to `p = angle / 180` (so 180 = fully open) and should call the same pipeline that `faSet(p)` uses (begin a fold animation object with `foldBegin`, update with `faSet(p)` on `input`, finish with `foldFinish(open,'drag')` on release). Do not rebuild the effect with CSS keyframes; keep a single `p` as the source of truth.

**Responsive content.** After `fold:state` apps use `body.form-fold`, `.fold-open`, `UI.isSplit()` and `UI.split(win, ...)` (list | detail) and the right rail (`UI.railOn/railFor`). The calculator, for example, shows its scientific keys on the left half only when open.

## 9. Where else motion lives

`css/shell.css` (31 keyframes: setup/hello animation, shake, pop, jiggle, orb, ring...), `css/lock.css`, `css/notify.css`, `css/ui.css` (sheets, alerts, toggles), `css/apps.css`, `css/app-*.css` (per-app), `js/sound.js` (click/swoosh/ring audio synced with motion), `js/shell/veravoice.js` + `vera.js` (assistant orb).
