# 03 - Apps catalog (generated from the live `App.all()` registry)

46 apps are registered when the reference runs. `id` is the stable key used by the dock, widgets, deep links (`phone://app/<id>`), notifications and the app switcher.

| id | name | category | core | defined in | extra CSS |
|---|---|---|---|---|---|
| aichat | Vera Chat | Utilidades | yes | js/apps/aichat.js:5 | app-aichat.css |
| appstore | AppShop | Utilitários | yes | js/apps/store.js:15 | app-store.css |
| calculator | Calculadora | Utilitários | yes | js/apps/calculator.js:2 | apps.css (shared) |
| calendar | Calendário | Utilitários | yes | js/apps/calendar.js:6 | apps.css (shared) |
| camera | Câmara | Criatividade | yes | js/apps/photos.js:862 | app-photoedit.css (+ camview.js) |
| clock | Relógio | Utilitários | yes | js/apps/clock.js:158 | apps.css (shared) |
| contacts | Contactos | Produtividade | yes | js/apps/phone.js:609 | apps.css (shared) |
| home | Casa | Estilo de vida | yes | js/apps/misc.js:6 | apps.css (shared) |
| mail | Mail | Comunicação | yes | js/apps/mail.js:111 | app-mail.css |
| maps | Mapas | Navegação | yes | js/apps/maps.js:146 | apps.css (shared) |
| messages | Mensagens | Comunicação | yes | js/apps/messages.js:9 | app-messages.css, app-groups.css |
| music | Música | Entretenimento | yes | js/apps/music.js:907 | app-music.css |
| notes | Notas | Utilitários | yes | js/apps/notes.js:7 | apps.css (shared) |
| phone | Telefone | Comunicação | yes | js/apps/phone.js:660 | apps.css (shared) |
| photos | Fotos | Criatividade | yes | js/apps/photos.js:330 | app-airdrop.css, app-photoedit.css |
| safari | Surf | Utilitários | yes | js/apps/safari.js:2 | apps.css (shared) |
| settings | Definições | Utilitários | yes | js/apps/settings.js:2 | apps.css (shared) |
| wallet | Carteira | Finanças | yes | js/apps/wallet.js:6 | app-wallet.css |
| weather | Meteorologia | Utilitários | yes | js/apps/weather.js:6 | apps.css (shared) |
| arcade | Arcade | Jogos |  | js/apps/games.js:1081 | app-games.css |
| billing | Faturas | Finanças |  | js/apps/billing.js:6 | app-wallet.css |
| blocks | Blocos | Jogos |  | (defined at runtime - shell/thirdparty or Lua) | apps.css (shared) |
| brick | Break | Jogos |  | (defined at runtime - shell/thirdparty or Lua) | apps.css (shared) |
| capp_bennys | Benny's | Empresas |  | (defined at runtime - shell/thirdparty or Lua) | apps.css (shared) |
| capp_burgershot | Burger Shot | Empresas |  | (defined at runtime - shell/thirdparty or Lua) | apps.css (shared) |
| capp_lspd | LSPD | Serviços públicos |  | (defined at runtime - shell/thirdparty or Lua) | apps.css (shared) |
| capp_pillbox | Pillbox | Serviços públicos |  | (defined at runtime - shell/thirdparty or Lua) | apps.css (shared) |
| crypto | Cripto | Anónimo |  | js/apps/crypto.js:9 | apps.css (shared) |
| darkchat | Dark Chat | Anónimo |  | js/apps/darkchat.js:2 | app-darkchat.css |
| eats | Eats | Comida |  | js/apps/eats.js:71 | app-eats.css |
| facetime | FaceCall | Comunicação |  | js/apps/phone.js:728 | app-facecall.css |
| findmy | Encontrar | Utilitários |  | js/apps/maps.js:386 | apps.css (shared) |
| g2048 | 2048 | Jogos |  | (defined at runtime - shell/thirdparty or Lua) | apps.css (shared) |
| garage | Garagem | Utilitários |  | js/apps/garage.js:4 | app-garage.css |
| instashot | Instashot | Redes sociais |  | js/apps/social.js:182 | app-social.css, app-social-dm.css, app-stories.css |
| marketplace | Marketplace | Compras |  | js/apps/marketplace.js:6 | app-marketplace.css |
| match | Match | Redes sociais |  | js/apps/match.js:14 | app-match.css |
| memory | Memória | Jogos |  | (defined at runtime - shell/thirdparty or Lua) | apps.css (shared) |
| mines | Minas | Jogos |  | (defined at runtime - shell/thirdparty or Lua) | apps.css (shared) |
| onion | Onion | Anónimo |  | js/apps/onion.js:14 | app-onion.css |
| radio | Rádio | Comunicação |  | js/apps/radio.js:541 | app-radio.css |
| recado | Zapp | Comunicação |  | js/apps/recado.js:9 | app-recado*.css (6 files) |
| reminders | Lembretes | Utilitários |  | js/apps/notes.js:133 | apps.css (shared) |
| services | Serviços | Utilitários |  | js/apps/services.js:2 | apps.css (shared) |
| snake | Snake | Jogos |  | (defined at runtime - shell/thirdparty or Lua) | apps.css (shared) |
| twix | Tweeter | Redes sociais |  | js/apps/social.js:707 | app-social.css, app-social-dm.css |

## Notes

- `core: yes` = system apps that ship installed (dock + first home page).
- Apps with `(defined at runtime ...)` are registered by `js/apps/thirdparty.js` / `capps.js` (apps added by other resources) or by a helper file; open them with `System.openApp('<id>')` once registered.
- App CSS is organised per app (`app-<name>.css`, with app-specific class prefixes such as `.calc` for the calculator). Shared building blocks (lists, nav bars, toggles, sheets) live in `css/ui.css` and `css/apps.css`.
- Android (Nova UI) skins of the same apps live in `css/oneui-apps1/2/3.css` and are active only under `body.os-android`; you can ignore them for an iOS-style prototype.
- In a plain browser (no FiveM) `Bridge` routes every call to `js/localdb.js`, a mock server that persists to `localStorage`. That is why all apps (messages, mail, wallet, social...) are interactive when you just open `index.html` through a local web server.
- App names in the registry are Portuguese (`Calculadora`, `Contactos`, `Definições`...). `js/i18n-en.js` translates every visible string at runtime; set the language to English in Settings (or add `lang` to the account) to see English labels.
