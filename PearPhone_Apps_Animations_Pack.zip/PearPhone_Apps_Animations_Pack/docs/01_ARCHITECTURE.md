# 01 - Architecture: why the reference apps are interactive

The reference (`reference/`) is a plain-JavaScript web UI (no build step, no framework). Everything is a global module loaded by `<script>` tags in `reference/index.html`. **The load order in that file matters** and is part of the design.

## 1. Layers (bottom to top)

| Layer | Files | Role |
|---|---|---|
| Data / transport | `js/store.js`, `js/bridge.js`, `js/localdb.js` | `Store` = persistent key/value (localStorage, per-character namespace). `Bridge` = one door to the "server": `Bridge.rpc/request(name, data)`; in a normal browser it is routed to `LocalDB`, a mock server that also persists to localStorage. Events: `Bridge.on/emit`. |
| Toolkit | `js/icons.js`, `js/ui.js`, `js/sound.js`, `js/wallpapers.js`, `js/locales.js`, `js/i18n*.js` | `UI` = mini-framework (views, push/pop navigation, lists, toggles, sheets, alerts, toasts, tab bars, context menus, swipe, long-press). `Icons` = SVG app icons and glyphs. |
| System | `js/system.js` | `App` registry, `System` (settings state, theme, status bar, **app windows**, **fold animation**, frames, boot). |
| Shell | `js/shell/*.js` | `Lock`, `Home`, `Notify`, `Island`, `CC` (control center), `Switcher`, `Gestures`, `Keyboard`, `Widgets`, `Setup` (first run wizard) ... |
| Apps | `js/apps/*.js` | Each app calls `App.define(id, {...})`. |
| Boot | `js/main.js` | Fills app metadata and calls `System.init()` on `DOMContentLoaded`. |

CSS follows the same order (`index.html`): `tokens.css` -> `system.css` -> `shell.css` -> `ui.css` -> `apps.css` -> `app-*.css` -> `notify/control/lock` -> `motion.css` -> `liquid27.css` -> Android skins (`oneui-*.css`, only active under `body.os-android`) -> extras. **`motion.css` and `liquid27.css` are loaded late on purpose so they override the transitions of earlier files.**

## 2. The app contract

```js
App.define('calculator', {
  name: 'Calculadora',          // label (translated at runtime by i18n)
  statusBar: 'dark',            // status bar tone while the app is open
  open(win)   { /* build the DOM into `win`, bind events, load data */ },
  resume(win) { /* optional: app comes back to foreground */ },
  pause(win)  { /* optional: app goes to background */ },
  back(win)   { /* optional: handle Back; return true if consumed */ },
  // optional: category, core, icon, description, needs, hidden ...
});
```

* `win` is the `.app-window` element created by `System.openApp(id, fromTileElement)`. The app owns everything inside it.
* The app builds real DOM with `UI.el('<div>...</div>')` and attaches **real event handlers** (clicks, pointer events, inputs). Nothing is pre-rendered markup. This is the single biggest difference from a static prototype.
* Inside an app, screens are pushed on a navigation stack: `UI.view`, `UI.push`, `UI.pop` (with parallax and the iOS back-swipe from `Gestures`).
* State lives in `Store` (`Store.get('notes', [])`, `Store.set('notes', list)`) or comes from the mock server through `Bridge.rpc('<namespace>.<method>', data)`. Keys such as notes, alarms, events are synced to the "server" automatically (`Store.SYNC`).
* Cross-module events go through `Bridge.emit/on` (`app:open`, `fold:state`, `form:changed`, `os:changed` ...). Apps and shell never call each other's internals.
* Notifications: `Notify.push({ app, title, msg, onTap, ... })`. Dynamic Island: `Island.set('call' | 'music' | ..., data)` or `Island.activity(id, data)`. Widgets: `Widgets.register({...})`.

Read next to the code: `animations/excerpts/C_App_registry_and_defaults_from_system.js.txt` (the `App` registry) and `apps/js/calculator.js` (smallest complete app, 280 lines) or `apps/js/notes.js` (CRUD + persistence).

## 3. Window lifecycle (what "opening an app" really does)

`System.openApp(id, fromEl)` (system.js ~758):
1. validates the app, handles the locked state (`Lock.requestUnlock`),
2. creates or reuses `windows[id]`, calls the app's `open(win)` (first time) or `resume(win)`,
3. computes the start rectangle from the tapped icon (`rectOf` / `toTransform`),
4. adds classes and uses a **double `requestAnimationFrame`** so the browser paints the start state before `.open` is added (this is what makes the transition actually run),
5. emits `app:open`, plays the sound, records usage.

`System.closeApp()` shrinks the window back to the icon (`shrinkTo`) and reveals the home screen. The animation details are in `02_ANIMATIONS.md`.

## 4. Form factors and the foldable

* `System.setFrame(frame)` picks the device. Frames: `black, white, blue, wine, orange, silver` (bar phones, 440x956), `fold-night, fold-star` (**PearPhone Fold**, iOS style), `flip-*` (NOVA Fold8, Android style), `s26-*` (Android bar).
* In a browser choose it with the URL hash: `reference/index.html#frame=fold-star`.
* `System.form` is `'bar'` or `'fold'`. A fold has two states: closed (outer screen 670x956) and open (inner screen 1340x956). `System.foldOpen`, `System.setFoldOpen(open, opts)`, `System.SW` (current screen width) and `System.FOLD` (measures). Events: `Bridge` `fold:state {open}` and `form:changed {from,to}` (apps and Home re-layout on them).
* Apps adapt to the fold with CSS classes on `<body>`: `form-fold`, `fold-open` / `fold-closed`. `UI.isFold()`, `UI.isSplit()` and `UI.split(win, {...})` give the "list | detail" two-pane layout when open. For the PearPhone Fold the app toolbar buttons move to a right-hand rail (`UI.railOn()`, `UI.railFor()`).

## 5. How to run the reference

```
cd reference
python -m http.server 8000
# open http://localhost:8000/#frame=fold-star     (or fold-night)
```
First launch shows a setup wizard (name, PIN...). PIN used by the demo UI text is `1225`. To skip the wizard in a test, create the account through the mock server and reload:
```js
Bridge.rpcRaw('account.create', { username:'Test', pin:'1225', avatar:'', settings:Object.assign({}, System.state, {setupDone:true}), face:'', nosim:false })
```
Useful console calls: `System.setFoldOpen(true)`, `System.openApp('notes')`, `System.setFrame('fold-star')`.

## 6. What can be dropped for a smaller prototype

Not needed for apps + animations: `js/admin.js`, `js/shop.js`, `js/shopviewer.js`, `js/shell/android-*.js`, `css/oneui-*.css`, `css/admin.css`, `css/shop.css`, `vendor/three`. If you remove a script, remove its `<script>` tag in `index.html`; the load order of the rest must stay the same.

Keep `js/gamerender.js` and `js/camview.js` if you keep the Camera / Instashot apps: they draw the camera viewfinder from the game view and must load before `apps/photos.js`. In a browser-only prototype you can drop those two apps and both files together. Game-specific apps (garage, radio, eSIM/pSIM, capps, onion, darkchat, match, marketplace) can also be left out; they are independent `App.define` modules.
