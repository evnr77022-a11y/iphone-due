# 04 - Differences between a typical AI-made prototype and this reference

The prototype itself was not available to the author of this pack (only two screenshots: a fold phone with a "Fold Phone / Fold Angle / Lock Phone / Call" control panel, widgets, an app grid and a lock screen with a notification). So the left column below is **what such prototypes usually do**. The AI doing the integration must open the real prototype and **confirm or reject each row**.

| Topic | Typical prototype (likely) | Reference (what to adopt) |
|---|---|---|
| What an app is | A static screen (markup pre-written in the HTML, or a few `onclick` toasts). Tapping an icon only shows/hides a div. | A **module** registered with `App.define(id, { open(win), resume, pause, back })`. `open` builds real DOM and binds real handlers. |
| Where state lives | Local variables, lost on reload, or none. | `Store.get/set` (persisted), `Bridge.rpc` to a mock server (`LocalDB`). Apps share data through it (a message sent in Messages shows in the notification, the badge on the icon, the lock screen). |
| Inside an app | One flat screen. | Navigation stack (`UI.view/push/pop`), tab bars, lists, sheets, alerts, action sheets, context menus, swipe actions, keyboards. |
| Cross-app behaviour | None. | Event bus (`Bridge.on/emit`), `Notify.push`, `Island.set`, badges, deep links `System.openURL('phone://app/<id>')`, widgets that read app data. |
| Opening animation | Toggle `display` or animate `width/height/left/top`; or a CSS animation that starts from the screen centre. | Window starts **on top of the tapped icon** (`rectOf`/`toTransform`), grows with `transform`, content fades in last; closes back into the icon. |
| Why transitions "don't play" | Class added in the same frame as the element is created or `display:none` is removed, so the browser skips the transition; or both start and end state are set at once. | Create element with start transform -> **double `requestAnimationFrame`** -> add `.open`. |
| Conflicting transitions | The same property has transitions in several rules, the last one wins unpredictably; `transition: all`. | One owner per state class (`.open`, `.closing`, `.dragging`, `.settle`); specific properties only; `motion.css` loads last. |
| Dragging | `transition` still active while dragging (laggy), layout read in `pointermove`, no release spring. | `.dragging {transition:none}` while down, spring on release, rubber-band, scale cached per gesture. |
| Gestures | Buttons only. | Home indicator drag -> card -> home/switcher, edge back swipe, top pulls for Control Center / Notifications, drag-scroll with the mouse. |
| Fold animation | CSS keyframes or a width change driven by the slider; the layout re-flows while it moves, or the two halves are separate unrelated divs. | One progress `p` in `[0..1]`; one leaf rotating with `perspective(3800px) rotateY(-180*p)` around the hinge; the front is the live closed screen; a rig behind draws the inner screen; geometry swap at 90 degrees; **only transform/opacity**; fallback timeout. |
| Fold content | Same layout in both states. | `fold:state` event, `body.form-fold / fold-open / fold-closed`, `UI.split` list-detail, right rail, apps re-layout after the animation ends. |
| App icons and widgets | Emoji or flat colour boxes, fixed positions. | Layered SVG icons (`Icons`), `Home` with pages, dock, folders, edit mode (drag and drop), resizable widgets (`Widgets.register`). |
| Lock screen | A picture and a clock. | `Lock` module: rolling clock, notifications stacks, PIN pad with real verification, wake/unlock animation, `requestUnlock` for deep links. |
| Settings | Visual only. | Settings toggles change `System.state`, which is applied to the whole UI (theme, accent, wallpaper, text size, Reduce Motion, Liquid Glass slider ...) and saved. |
| Performance | `backdrop-filter`/`filter` everywhere, animating shadows and blur. | Blur is pre-rendered once into a cached image (`makeBlur`); shadows live on the element that does not animate; no layout reads in loops. |

## Things that make the reference feel "real" (do not skip them)

1. A **single global state** (`System.state`) plus `Store`: every setting is read from there, so the whole UI reacts.
2. **Sound and haptics** hooks (`Sound.play('click'|'swoosh'|'error')`).
3. **Badges and notifications** tied to app data (`Home.badges`, `Notify.push`).
4. **Idempotent registration**: `App.define` can be called again with the same data and nothing re-renders.
5. **Defensive code**: every handler wrapped in try/catch, timeouts so nothing stays half-animated.

## Integration strategies (the AI should pick one and say why)

**A. Adopt the runtime (recommended).** Keep the reference scripts and CSS as they are (they are already tested together), drop in the prototype's *look* by editing `tokens.css`, `liquid27.css`, wallpapers, `Icons`, and the control panel. Add the prototype's extra controls (Fold Angle slider, Lock Phone, Call button) as a small separate script that talks to `System.setFoldOpen`, `Lock.lock()`, `Island.set('call', ...)`. Least risk, everything interactive immediately.

**B. Port the concepts into the prototype's own code.** Only if the prototype must stay a single small file or use a framework. Port in this order: (1) `App.define` registry + window lifecycle + double-rAF open/close, (2) `Store` + a few real apps (Calculator, Notes, Clock, Calendar, Messages, Settings), (3) gestures + switcher, (4) the fold `p` animation, (5) lock screen. Test after each step.

In both cases the AI must deliver **complete files** (not snippets), and a short list of what was kept, replaced and removed.
